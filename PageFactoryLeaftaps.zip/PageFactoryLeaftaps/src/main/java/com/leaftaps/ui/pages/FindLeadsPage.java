package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class FindLeadsPage extends ProjectSpecificMethods
{
	public FindLeadsPage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (xpath="//span[text()='Phone']") WebElement elePhoneTab;
	@FindBy (xpath="//input[@name='phoneNumber']") WebElement elePhoneNumber;
	@FindBy (xpath="//button[text()='Find Leads']") WebElement eleFindLeads;
	@FindBy (xpath="//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a") WebElement eleFirstLead;
	@FindBy (xpath="//input[@name='id']") WebElement eleLeadID;
	@FindBy (className="x-paging-info") WebElement eleVerifyID;	
	public FindLeadsPage clickPhoneTab()
	{
		elePhoneTab.click();
		return this;
	}
	
	public FindLeadsPage enterPhoneNumber(String number)
	{
		elePhoneNumber.sendKeys(number);
		return this;
	}
	
	public FindLeadsPage clickFindLeads() throws InterruptedException
	{
		eleFindLeads.click();
		Thread.sleep(2000);
		return this;
	}
	
	public ViewLeadPage clickFirstLead()
	{
		eleFirstLead.click();
		return new ViewLeadPage(driver);
	}
	
	public FindLeadsPage getLeadID()
	{
		eleLeadID.sendKeys(leadID);
		return this; 
	}
	
	public FindLeadsPage setLeadID()
	{
		eleLeadID.sendKeys(leadID);
		return this; 
	}
	
	public FindLeadsPage verifyLead()
	{
		String text = eleVerifyID.getText();
		if (text.contains("No records to display")) 
		{
			System.out.println("No records");
		} 
		else 
		{
			System.out.println("Displaying records");
		}
		
		return this;
	}
	
	public FindLeadsPage storeLeadID()
	{
		leadID = eleFirstLead.getText();
		return this;
	}
}
