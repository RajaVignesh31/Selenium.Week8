package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods
{
	public CreateLeadPage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (id="createLeadForm_companyName") WebElement eleCompanyName;
	@FindBy (id="createLeadForm_firstName") WebElement eleFirstName;
	@FindBy (id="createLeadForm_lastName") WebElement eleLastName;
	@CacheLookup @FindBy (name="submitButton") WebElement eleCreateLeadButton;
	
	public CreateLeadPage enterCompanyName(String companyName)
	{
		eleCompanyName.sendKeys(companyName);
		return this;
	}
	
	public CreateLeadPage enterFirstName(String firstName)
	{
		eleFirstName.sendKeys(firstName);
		return this;
	}
	
	public CreateLeadPage enterLastName(String lastName)
	{
		eleLastName.sendKeys(lastName);
		return this;
	}
	
	public ViewLeadPage clickCreateLeadButton()
	{
		eleCreateLeadButton.click();
		return new ViewLeadPage(driver);
	}
}
