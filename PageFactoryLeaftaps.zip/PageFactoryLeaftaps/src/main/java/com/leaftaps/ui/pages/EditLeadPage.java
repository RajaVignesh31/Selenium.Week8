package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class EditLeadPage extends ProjectSpecificMethods
{
	public EditLeadPage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (id="updateLeadForm_companyName") WebElement eleCompanyName;
	@FindBy (name="submitButton") WebElement eleUpdate;
	public EditLeadPage enterCompanyName(String companyName)
	{
		eleCompanyName.clear();
		eleCompanyName.sendKeys(companyName);
		return this;
	}
	
	public ViewLeadPage clickUpdateButton()
	{
		eleUpdate.click();
		return new ViewLeadPage(driver);
	}
}
