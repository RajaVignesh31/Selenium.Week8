package com.leaftaps.ui.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.pages.LoginPage;

import Base.ProjectSpecificMethods;

public class TC03_DuplicateLead extends ProjectSpecificMethods
{
	// 2. Find the Before Test and set the excel file name
	@BeforeTest
	public void setData()
	{
		excelFilePath = "./TestData/tc003.xlsx";
	}
	
	// 1. From XML the control will come here
	// 6. From here start the execution
	@Test(dataProvider = "Dynamic_Data")
	public void run03_DuplicateLead(String userName, String password, String phoneNumber) throws InterruptedException
	{
		new LoginPage(driver)
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton_Success()
		.clickCRMSFA()
		.clickLeadsTab()
		.findLeads()
		.clickPhoneTab()
		.enterPhoneNumber(phoneNumber)
		.clickFindLeads()
		.clickFirstLead()
		.clickDuplicateLead()
		.clickCreateDuplicateLead();
	}
}
