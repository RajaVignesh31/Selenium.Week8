package com.leaftaps.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class MergeLeadsPage extends ProjectSpecificMethods
{
	public MergeLeadsPage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (xpath="(//span[text()='From Lead']/following::img)[1]") WebElement eleFromLead;
	@FindBy (xpath="(//span[text()='To Lead']/following::img)[1]") WebElement eleToLead;
	@FindBy (xpath="//a[text()='Merge']") WebElement eleMerge;
	public FindLeadsLookUpPage fromLead()
	{
		eleFromLead.click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(1));
		return new FindLeadsLookUpPage(driver);
	}
	
	public FindLeadsLookUpPage toLead()
	{
		eleToLead.click();
		Set<String> allWindows2 = driver.getWindowHandles();
		List<String> allhandles2 = new ArrayList<String>(allWindows2);
		driver.switchTo().window(allhandles2.get(1));
		return new FindLeadsLookUpPage(driver);
	}
	
	public ViewLeadPage clickMerge()
	{
		eleMerge.click();
		driver.switchTo().alert().accept();
		return new ViewLeadPage(driver);
	}
}
