package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class DuplicateLeadPage extends ProjectSpecificMethods
{
	public DuplicateLeadPage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (name="submitButton") WebElement eleSubmit;
	public ViewLeadPage clickCreateDuplicateLead()
	{
		eleSubmit.click();
		return new ViewLeadPage(driver);
	}
}
