package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods
{
	public WelcomePage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (linkText="CRM/SFA") WebElement eleCrmsfa;
	@FindBy (className="decorativeSubmit") WebElement eleDecorativeSubmit;
	public HomePage clickCRMSFA()
	{
		eleCrmsfa.click();
		return new HomePage(driver);
	}
	
	public LoginPage clickLogout()
	{
		eleDecorativeSubmit.click();
		return new LoginPage(driver);
	}
}
