package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class LeadsPage extends ProjectSpecificMethods
{
	public LeadsPage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (linkText = "Create Lead") WebElement eleCreateLead;
	@FindBy (linkText = "Find Leads") WebElement eleFindLeads;
	@FindBy (linkText = "Merge Leads") WebElement eleMergeLeads;
	public CreateLeadPage clickCreateLead()
	{
		eleCreateLead.click();
		return new CreateLeadPage(driver);
	}
	
	public FindLeadsPage findLeads()
	{
		eleFindLeads.click();
		return new FindLeadsPage(driver);
	}
	
	public MergeLeadsPage mergeLeads()
	{
		eleMergeLeads.click();
		return new MergeLeadsPage(driver);
	}
}