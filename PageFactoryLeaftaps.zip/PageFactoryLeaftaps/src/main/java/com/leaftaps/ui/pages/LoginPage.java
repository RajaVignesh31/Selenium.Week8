package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods
{
	public LoginPage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@CacheLookup @FindBy(how = How.ID, using = "username") WebElement eleUsername;
	@FindBys({@FindBy(id = "username"), @FindBy(name = "USERNAME")}) WebElement element1; // Logical AND
	@FindAll({@FindBy(id = "username"), @FindBy(name = "USERNAME")}) WebElement element2; // Logical OR
	//@FindBy(how = How.ID, using = "username") WebElement eleUsername; // WebElement eleUserName = driver.findElement(By.id("username"));
	@FindBy(id = "password") WebElement elePassword; // WebElement elePassword = driver.findElement(By.id("password"));
	@FindBy(xpath = "//input[@class='decorativeSubmit']") WebElement eleLogin;
	
	public LoginPage enterUserName(String userName)
	{
		element2.sendKeys(userName);
		//LoginPage page = new LoginPage();
		//return page;
		//return new LoginPage();
		return this;
	}
	
	public LoginPage enterPassword(String password)
	{
		elePassword.sendKeys(password);
		return this;
	}
	
	public WelcomePage clickLoginButton_Success()
	{
		eleLogin.click();
		return new WelcomePage(driver);
	}
	
	public LoginPage clickLoginButton_Failure()
	{
		eleLogin.click();
		return this;
	}
}
