package com.leaftaps.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class FindLeadsLookUpPage extends ProjectSpecificMethods 
{
	public FindLeadsLookUpPage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//input[@name='firstName']") WebElement eleFirstName;
	@FindBy(xpath="//button[text()='Find Leads']") WebElement eleFindLeads;
	@FindBy(xpath="//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a") WebElement eleFirstLead;
	public FindLeadsLookUpPage enterFirstName1(String firstname1)
	{
		eleFirstName.sendKeys(firstname1);
		return this;
	}
	
	public FindLeadsLookUpPage clickFindLeads() throws InterruptedException
	{
		eleFindLeads.click();
		Thread.sleep(2000);
		return this;
	}
	
	public MergeLeadsPage clickFirstLead()
	{
		leadID = eleFirstLead.getText();
		eleFirstLead.click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(0));
		return new MergeLeadsPage(driver);
	}	
	
	public FindLeadsLookUpPage enterFirstName2(String firstname2)
	{
		eleFirstName.sendKeys(firstname2);
		return this;
	}
}
