package com.leaftaps.ui.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.pages.LoginPage;

import Base.ProjectSpecificMethods;

public class TC05_DeleteLead extends ProjectSpecificMethods
{
	// 2. Find the Before Test and set the excel file name
	@BeforeTest
	public void setData()
	{
		excelFilePath = "./TestData/tc005.xlsx";
	}
	
	// 1. From XML the control will come here
	// 6. From here start the execution
	@Test(dataProvider = "Dynamic_Data")
	public void run05_DeleteLead(String userName, String password, String phoneNumber) throws InterruptedException
	{
		new LoginPage(driver)
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton_Success()
		.clickCRMSFA()
		.clickLeadsTab()
		.findLeads()
		.clickPhoneTab()
		.enterPhoneNumber(phoneNumber)
		.clickFindLeads()
		.storeLeadID()
		.clickFirstLead()
		.clickDelete()
		.findLeads()
		.setLeadID()
		.clickFindLeads()
		.verifyLead();
	}
}
