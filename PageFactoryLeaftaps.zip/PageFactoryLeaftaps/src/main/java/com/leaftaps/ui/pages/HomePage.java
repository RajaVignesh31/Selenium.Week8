package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods
{
	public HomePage(RemoteWebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (linkText="Leads") WebElement eleLeads;
	public LeadsPage clickLeadsTab()
	{
		eleLeads.click();
		return new LeadsPage(driver);
	}
}
