package com.leaftaps.ui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods
{
	public ViewLeadPage(RemoteWebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy (id="viewLead_companyName_sp") WebElement eleCompanyName;
	@FindBy (linkText="Edit") WebElement eleEdit;
	@FindBy (linkText="Duplicate Lead") WebElement eleDuplicateLead;
	@FindBy (linkText="Find Leads") WebElement eleFindLeads;
	@FindBy (linkText="Delete") WebElement eleDelete;
	public ViewLeadPage verifyLeadID()
	{
		String text = eleCompanyName.getText();
		System.out.println("Lead ID : " + text);
		return this;
	}
	
	public EditLeadPage clickEditLead()
	{
		eleEdit.click();
		return new EditLeadPage(driver);
	}
	
	public DuplicateLeadPage clickDuplicateLead()
	{
		eleDuplicateLead.click();
		return new DuplicateLeadPage(driver);
	}
	
	public FindLeadsPage clickFindLead()
	{
		eleFindLeads.click();
		return new FindLeadsPage(driver);
	}
	
	public LeadsPage clickDelete()
	{
		eleDelete.click();
		return new LeadsPage(driver);
	}
}
