package Property;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public final class LearnProperty
{
	public static void main(String[] args) throws IOException
	{
		// This class helps to read the property file
		Properties prop = new Properties();
	  
		// Creating a new FileInputStream, to make the given file as a readable component
		FileInputStream file = new FileInputStream("src/main/resources/AppConfig.properties");
	  
		// Load the property input file
		prop.load(file);
	  
		// To get the data out or properties file using the key
		String url = prop.getProperty("appURL");
		System.out.println(url);
	  
		String browserName = prop.getProperty("browser");
		System.out.println(browserName);
	}
}
