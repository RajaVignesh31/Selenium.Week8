package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethods;

public class LeadsPage extends ProjectSpecificMethods
{
	public LeadsPage(RemoteWebDriver driver)
	{
		this.driver = driver;
	}
	
	public CreateLeadPage clickCreateLead()
	{
		driver.findElement(By.linkText(prop.getProperty("linkText_createLead"))).click();
		return new CreateLeadPage(driver);
	}
	
	public FindLeadsPage findLeads()
	{
		driver.findElement(By.linkText(prop.getProperty("linkText_findLeads"))).click();
		return new FindLeadsPage(driver);
	}
	
	public MergeLeadsPage mergeLeads()
	{
		driver.findElement(By.linkText(prop.getProperty("linkText_mergeLeads"))).click();
		return new MergeLeadsPage(driver);
	}
}
