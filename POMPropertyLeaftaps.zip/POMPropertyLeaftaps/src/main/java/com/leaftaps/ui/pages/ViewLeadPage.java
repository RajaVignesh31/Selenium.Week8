package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods
{
	public ViewLeadPage(RemoteWebDriver driver) 
	{
		this.driver = driver;
	}
	
	public ViewLeadPage verifyLeadID()
	{
		String text = driver.findElement(By.id(prop.getProperty("id_companyNameVL"))).getText();
		System.out.println("Lead ID : " + text);
		return this;
	}
	
	public EditLeadPage clickEditLead()
	{
		driver.findElement(By.linkText(prop.getProperty("linkText_edit"))).click();
		return new EditLeadPage(driver);
	}
	
	public DuplicateLeadPage clickDuplicateLead()
	{
		driver.findElement(By.linkText(prop.getProperty("linkText_duplicateLead"))).click();
		return new DuplicateLeadPage(driver);
	}
	
	public FindLeadsPage clickFindLead()
	{
		driver.findElement(By.linkText(prop.getProperty("linkText_findLeadsVL"))).click();
		return new FindLeadsPage(driver);
	}
	
	public LeadsPage clickDelete()
	{
		driver.findElement(By.linkText(prop.getProperty("linkText_delete"))).click();
		return new LeadsPage(driver);
	}
}
