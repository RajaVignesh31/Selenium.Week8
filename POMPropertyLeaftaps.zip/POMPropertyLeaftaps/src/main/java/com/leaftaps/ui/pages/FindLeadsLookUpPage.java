package com.leaftaps.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethods;

public class FindLeadsLookUpPage extends ProjectSpecificMethods 
{
	public FindLeadsLookUpPage(RemoteWebDriver driver)
	{
		this.driver = driver;
	}
	
	public FindLeadsLookUpPage enterFirstName1(String firstname1)
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_firstName"))).sendKeys(firstname1);
		return this;
	}
	
	public FindLeadsLookUpPage clickFindLeads() throws InterruptedException
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_findLeads"))).click();
		Thread.sleep(2000);
		return this;
	}
	
	public MergeLeadsPage clickFirstLead()
	{
		leadID = driver.findElement(By.xpath(prop.getProperty("xpath_firstLead"))).getText();
		driver.findElement(By.xpath(prop.getProperty("xpath_firstLead"))).click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(0));
		return new MergeLeadsPage(driver);
	}	
	
	public FindLeadsLookUpPage enterFirstName2(String firstname2)
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_firstName"))).sendKeys(firstname2);
		return this;
	}
}
