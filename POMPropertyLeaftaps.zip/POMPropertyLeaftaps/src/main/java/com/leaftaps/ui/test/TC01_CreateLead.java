package com.leaftaps.ui.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.pages.LoginPage;

import Base.ProjectSpecificMethods;

public class TC01_CreateLead extends ProjectSpecificMethods
{
	// 2. Find the Before Test and set the excel file name
	@BeforeTest
	public void setData()
	{
		excelFilePath = "./TestData/tc001.xlsx";
	}
	
	// 1. From XML the control will come here
	// 6. From here start the execution
	@Test(dataProvider = "Dynamic_Data")
	public void run01_CreateLead(String userName, String password, String companyName, String firstName, String lastName)
	{
		new LoginPage(driver)
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton_Success()
		.clickCRMSFA()
		.clickLeadsTab()
		.clickCreateLead()
		.enterCompanyName(companyName)
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.clickCreateLeadButton()
		.verifyLeadID();
	}
}
