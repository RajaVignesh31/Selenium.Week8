package com.leaftaps.ui.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.pages.LoginPage;

import Base.ProjectSpecificMethods;

public class TC02_EditLead extends ProjectSpecificMethods
{
	// 2. Find the Before Test and set the excel file name
	@BeforeTest
	public void setData()
	{
		excelFilePath = "./TestData/tc002.xlsx";
	}
	
	// 1. From XML the control will come here
	// 6. From here start the execution
	@Test(dataProvider = "Dynamic_Data")
	public void run02_EditLead(String userName, String password, String phoneNumber, String companyName) throws InterruptedException
	{
		new LoginPage(driver)
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton_Success()
		.clickCRMSFA()
		.clickLeadsTab()
		.findLeads()
		.clickPhoneTab()
		.enterPhoneNumber(phoneNumber)
		.clickFindLeads()
		.clickFirstLead()
		.clickEditLead()
		.enterCompanyName(companyName)
		.clickUpdateButton();
	}
}
