package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethods;

public class EditLeadPage extends ProjectSpecificMethods
{
	public EditLeadPage(RemoteWebDriver driver)
	{
		this.driver = driver;
	}
	
	public EditLeadPage enterCompanyName(String companyName)
	{
		driver.findElement(By.id(prop.getProperty("id_companyNameEL"))).clear();
		driver.findElement(By.id(prop.getProperty("id_companyNameEL"))).sendKeys(companyName);
		return this;
	}
	
	public ViewLeadPage clickUpdateButton()
	{
		driver.findElement(By.name(prop.getProperty("name_submitEL"))).click();
		return new ViewLeadPage(driver);
	}
}
