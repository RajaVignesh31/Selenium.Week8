package com.leaftaps.ui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethods;

public class FindLeadsPage extends ProjectSpecificMethods
{
	public FindLeadsPage(RemoteWebDriver driver)
	{
		this.driver = driver;
	}
	
	public FindLeadsPage clickPhoneTab()
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_phone"))).click();
		return this;
	}
	
	public FindLeadsPage enterPhoneNumber(String number)
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_phoneNumber"))).sendKeys(number);
		return this;
	}
	
	public FindLeadsPage clickFindLeads() throws InterruptedException
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_findLeadsFL"))).click();
		Thread.sleep(2000);
		return this;
	}
	
	public ViewLeadPage clickFirstLead()
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_firstLeadFL"))).click();
		return new ViewLeadPage(driver);
	}
	
	public FindLeadsPage getLeadID()
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_getLeadID"))).sendKeys(leadID);
		return this; 
	}
	
	public FindLeadsPage setLeadID()
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_setLeadID"))).sendKeys(leadID);
		return this; 
	}
	
	public FindLeadsPage verifyLead()
	{
		String text = driver.findElement(By.className(prop.getProperty("className_verifyLead"))).getText();
		if (text.contains("No records to display")) 
		{
			System.out.println("No records");
		} 
		else 
		{
			System.out.println("Displaying records");
		}
		
		return this;
	}
	
	public FindLeadsPage storeLeadID()
	{
		leadID = driver.findElement(By.xpath(prop.getProperty("xpath_storeLeadID"))).getText();
		return this;
	}
}
