package com.leaftaps.ui.pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethods;

public class MergeLeadsPage extends ProjectSpecificMethods
{
	public MergeLeadsPage(RemoteWebDriver driver)
	{
		this.driver = driver;
	}
	
	public FindLeadsLookUpPage fromLead()
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_lookUpPageFromLead"))).click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(1));
		return new FindLeadsLookUpPage(driver);
	}
	
	public FindLeadsLookUpPage toLead()
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_lookUpPageToLead"))).click();
		Set<String> allWindows2 = driver.getWindowHandles();
		List<String> allhandles2 = new ArrayList<String>(allWindows2);
		driver.switchTo().window(allhandles2.get(1));
		return new FindLeadsLookUpPage(driver);
	}
	
	public ViewLeadPage clickMerge()
	{
		driver.findElement(By.xpath(prop.getProperty("xpath_merge"))).click();
		driver.switchTo().alert().accept();
		return new ViewLeadPage(driver);
	}
}
