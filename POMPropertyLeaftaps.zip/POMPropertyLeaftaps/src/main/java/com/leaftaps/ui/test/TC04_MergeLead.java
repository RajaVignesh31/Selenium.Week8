package com.leaftaps.ui.test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.pages.LoginPage;

import Base.ProjectSpecificMethods;

public class TC04_MergeLead extends ProjectSpecificMethods
{
	// 2. Find the Before Test and set the excel file name
	@BeforeTest
	public void setData()
	{
		excelFilePath = "./TestData/tc004.xlsx";
	}
	
	// 1. From XML the control will come here
	// 6. From here start the execution
	@Test(dataProvider = "Dynamic_Data")
	public void run04_MergeLead(String userName, String password, String firstName1, String firstName2) throws InterruptedException
	{
		new LoginPage(driver)
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton_Success()
		.clickCRMSFA()
		.clickLeadsTab()
		.mergeLeads()
		.fromLead()
		.enterFirstName1(firstName1)
		.clickFindLeads()
		.clickFirstLead()
		.toLead()
		.enterFirstName2(firstName2)
		.clickFindLeads()
		.clickFirstLead()
		.clickMerge()
		.clickFindLead()
		.getLeadID()
		.clickFindLeads()
		.verifyLead();
	}
}
