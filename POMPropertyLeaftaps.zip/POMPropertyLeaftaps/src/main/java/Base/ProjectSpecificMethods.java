package Base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcelGeneric;

public class ProjectSpecificMethods 
{
	public RemoteWebDriver driver;
	public String excelFilePath;
	public static String leadID;
	public static Properties prop;
	
	// 4. Configure the @ Test with the number of test data
	//@Parameters ({"URL","BROWSER"})
	@BeforeMethod 
	public void beforeMethod() throws IOException
	{
		// This class helps to read the property file
		prop = new Properties();
		
		// Creating a new FileInputStream, to make the given file as a readable component
		FileInputStream file = new FileInputStream("src/main/resources/AppConfig.properties");
		
		// Load the property input file
		prop.load(file);
		
		// To get the data out or properties file using the key
		String url = prop.getProperty("appURL");
		System.out.println(url);
		
		String browserName = prop.getProperty("browser");
		System.out.println(browserName);
				
		if(browserName.equalsIgnoreCase("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		else if(browserName.equalsIgnoreCase("edge"))
		{
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	// 5. Get driver as static
	@AfterMethod 
	public void afterMethod()
	{
		driver.close();
	}
	
	// 3. Read the excel given data in 2D array
	@DataProvider(name = "Dynamic_Data")
	public String[][] testData() throws IOException
	{
		// 3.1 Read the excel data
		String data[][] = ReadExcelGeneric.getData(excelFilePath);
		
		return data;
	}	
}
